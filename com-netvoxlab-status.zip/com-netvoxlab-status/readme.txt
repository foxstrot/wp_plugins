﻿=== Модуль фейкового просмотра статуса заявки===
Contributors: netvoxlab
Tags: radio, ownRadio, broadcast, music online
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 2017.02.22
License: GPLv3

== Description ==

Модуль фейкового просмотра статуса заявки

Shortcode: [netvoxlab_check_status]