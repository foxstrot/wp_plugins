﻿=== Модуль просмотра статуса заявления===
Contributors: netvoxlab
Tags: radio, ownRadio, broadcast, music online
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 2017.03.22
License: GPLv3

== Description ==

Модуль просмотра статуса заявления

Shortcode: [netvoxlab_check_status]