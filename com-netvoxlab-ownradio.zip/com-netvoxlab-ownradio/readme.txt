﻿=== ownRadio ===
Contributors: foxstrot
Tags: radio, ownRadio, broadcast, music online
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 2017.02.02
License: GPLv2

== Description ==

Broadcast radio ownRadio. Listen to your favorite music only.

Shortcode for input radio: [ownradio_player]

Contact us:
* Facebook: https://www.facebook.com/groups/ownRadio
* VKontakte: https://vk.com/ownradio

ownRadio available:
* on the web-site: http://www.ownradio.ru
* on the App Store: https://itunes.apple.com/app/ownradio/id1179868370?mt=8
* on the Google Play: https://play.google.com/store/apps/details?id=ru.netvoxlab.ownradio

== Installation ==

1. Upload the 'myplugin' folder to the '/wp-content/plugins' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= How to insert player to page?

You need to insert shortcode [ownradio_player] in the page.

== Screenshots ==

1. This is the main view of ownRadio player.

== Changelog ==

= 2017.02.02 =
This is the first version.

== Upgrade Notice ==

= 2017.02.02 =
This is the first version.